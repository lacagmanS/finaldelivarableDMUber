package com.example.dmuber

import android.Manifest
import android.app.ProgressDialog
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Location
import android.os.Bundle
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.firebase.geofire.GeoFire
import com.firebase.geofire.GeoLocation
import com.firebase.geofire.GeoQueryEventListener
import com.firebase.geofire.core.GeoHash
import com.google.android.gms.location.*
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.maps.android.SphericalUtil
import java.util.Locale


class DriverMapsActivity : AppCompatActivity(), OnMapReadyCallback  {

    private lateinit var mMap: GoogleMap
    private lateinit var mapView: MapView


    private lateinit var locationRequest: LocationRequest
    private lateinit var locationCallback: LocationCallback
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient

    private lateinit var onlineRef: DatabaseReference
    private lateinit var currentUserRef: DatabaseReference
    private lateinit var driversLocationRef: DatabaseReference
    private lateinit var geoFire: GeoFire

    private lateinit var progressDialog: ProgressDialog

    private val onlineValueEventListener = object : ValueEventListener {
        override fun onCancelled(error: DatabaseError) {
            Snackbar.make(findViewById(android.R.id.content), error.message, Snackbar.LENGTH_LONG)
                .show()
        }

        override fun onDataChange(snapshot: DataSnapshot) {
            if (snapshot.exists()) {
                currentUserRef.onDisconnect().removeValue()
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)

        progressDialog = ProgressDialog(this)

        mapView = findViewById(R.id.map_view)
        mapView.onCreate(savedInstanceState)
        mapView.onResume()
        mapView.getMapAsync(this)

        init()


    }

    private fun init() {
        onlineRef = FirebaseDatabase.getInstance().getReference(".info/connected")
        driversLocationRef =
            FirebaseDatabase.getInstance().getReference("DriverLocationReference")
        currentUserRef = FirebaseDatabase.getInstance().getReference("DriverLocationReference")
            .child(FirebaseAuth.getInstance().currentUser!!.uid)

        geoFire = GeoFire(driversLocationRef)

        registerOnlineSystem()

        locationRequest = LocationRequest()
        locationRequest.apply {
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
            fastestInterval = 3000
            interval = 5000
            smallestDisplacement = 10f
        }

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                super.onLocationResult(locationResult)
                val location = locationResult.lastLocation
                location?.let { updateLocation(it) }
            }
        }

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)
        startLocationUpdates()
    }

    private fun startLocationUpdates() {
        Log.d("LocationUpdates", "startLocationUpdates() called")
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationProviderClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
            )
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                12
            )
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.mapType = GoogleMap.MAP_TYPE_NORMAL



        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            mMap.isMyLocationEnabled = true
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        }

    }


    private fun updateLocation(location: Location) {
        Log.d("update location", "updateLocation() called")
        val newPos = LatLng(location.latitude, location.longitude)
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(newPos, 18f))
        geoFire.setLocation(
            FirebaseAuth.getInstance().currentUser!!.uid,
            GeoLocation(location.latitude, location.longitude)
        ) { key: String?, error: DatabaseError? ->
            if (error != null) {
                Snackbar.make(
                    findViewById(android.R.id.content),
                    error.message,
                    Snackbar.LENGTH_LONG
                ).show()
            } else {
                Snackbar.make(
                    findViewById(android.R.id.content),
                    "You're online!",
                    Snackbar.LENGTH_SHORT
                ).show()

                Log.d("online", "onlineeeeeeeeeeeeeeeeeeeeeeeeeeeeee")
                startListeningForCarpoolRequests()
            }
        }
    }

    private fun registerOnlineSystem() {
        onlineRef.addValueEventListener(onlineValueEventListener)
    }

    override fun onDestroy() {
        super.onDestroy()
        fusedLocationProviderClient.removeLocationUpdates(locationCallback)
        geoFire.removeLocation(FirebaseAuth.getInstance().currentUser!!.uid)
        onlineRef.removeEventListener(onlineValueEventListener)
    }



    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 100
    }



    private fun startListeningForCarpoolRequests() {
        Log.d("startListeningForCarpoolRequests", "startListeningForCarpoolRequests() called")
        val requestsRef = FirebaseDatabase.getInstance().getReference("CarpoolRequests")

        requestsRef.addChildEventListener(object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {

                val destinationSnapshot = snapshot.child("destination")
                val latitude = destinationSnapshot.child("latitude").getValue(Double::class.java)
                val longitude = destinationSnapshot.child("longitude").getValue(Double::class.java)
                if (latitude != null && longitude != null) {
                    val customerDestination = LatLng(latitude, longitude)

                    // Get the customer's name from the database
                    val customerUid = snapshot.child("uid").getValue(String::class.java)
                    val customerLocationRef = FirebaseDatabase.getInstance().getReference("CustomerLocationReference")
                        .child(customerUid ?: "")
                    val customersRef = FirebaseDatabase.getInstance().getReference("Customers")
                    customersRef.child(customerUid ?: "").addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(dataSnapshot: DataSnapshot) {
                            val customerName = dataSnapshot.child("fullName").getValue(String::class.java)
                            if (customerName != null) {
                                Log.d("Customerdestination", "Updating destination to: $customerDestination")

                                mMap.addMarker(MarkerOptions().position(customerDestination).title("$customerName's Destination "))
                                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(customerDestination, 15f))
                                showLocationRequestAlert(customerName, customerDestination)

                                Log.d("destination marker put", "putttttttttttttttttttttttttttttttttttttttttttt")
                            } else {
                                // Handle case where customer name is not found
                                Snackbar.make(findViewById(android.R.id.content), "Customer name not found", Snackbar.LENGTH_LONG).show()
                            }
                        }

                        override fun onCancelled(databaseError: DatabaseError) {
                            // Handle error (if needed)
                            Snackbar.make(findViewById(android.R.id.content), "Failed to retrieve customer name", Snackbar.LENGTH_LONG).show()
                        }
                    })
                }

                // Get the GeoHash from the CustomerLocationReference
                val customerUid = snapshot.child("uid").getValue(String::class.java)
                val customerLocationRef = FirebaseDatabase.getInstance().getReference("CustomerLocationReference")
                    .child(customerUid ?: "")
                customerLocationRef.addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                        val geoHash = dataSnapshot.child("g").getValue(String::class.java)
                        geoHash?.let { initiateGeoQuery(it) }
                    }

                    override fun onCancelled(databaseError: DatabaseError) {
                        // Handle error
                    }
                })

            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                // Handle changes to existing requests (if needed)
            }

            override fun onChildRemoved(snapshot: DataSnapshot) {


            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {
                // Handle moved requests (if needed)
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error (if needed)
            }
        })

    }


    private fun initiateGeoQuery(geoFireHash: String) {
        val geoQuery = geoFire.queryAtLocation(geoLocationFromGeoHash(geoFireHash), 1.0) // 1.0 is the radius in kilometers, adjust as needed
        geoQuery.addGeoQueryEventListener(object : GeoQueryEventListener {
            override fun onKeyEntered(key: String?, location: GeoLocation?) {
                location?.let {
                    val customerLocation = LatLng(it.latitude, it.longitude)
                    updateCustomerBlipPosition(customerLocation)
                    Log.d("got here111111111111", "hereeeeeeeeeeeeeeeeeeeeee111: $location")

                }
            }

            override fun onKeyExited(key: String?) {
                // Handle case when the key exits
            }

            override fun onKeyMoved(key: String?, location: GeoLocation?) {
                location?.let {
                    val customerLocation = LatLng(it.latitude, it.longitude)
                    updateCustomerBlipPosition(customerLocation)
                    Log.d("got here", "hereeeeeeeeeeeeeeeeeeeeeeeeeee: $location")

                }
            }

            override fun onGeoQueryReady() {
                // All initial data has been loaded and events have been fired
            }

            override fun onGeoQueryError(error: DatabaseError?) {
                // Handle error
            }
        })
    }

    // Function to update blip's position on the map
    private fun updateCustomerBlipPosition(location: LatLng) {




        val iconBitmap = BitmapFactory.decodeResource(resources, R.drawable.ic_launcher)
        val width = 50
        val height = 50
        val resizedBitmap = Bitmap.createScaledBitmap(iconBitmap, width, height, false)
        val icon = BitmapDescriptorFactory.fromBitmap(resizedBitmap)
        val markerOptions = MarkerOptions()
            .position(location)
            .icon(icon)
            .anchor(0.5f, 0.5f)
        mMap.addMarker(markerOptions)
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 15f))
        Log.d("big blip", "blipppppppppppppppppppppppppppppppppppppo: $location")


    }

    private fun geoLocationFromGeoHash(geoHash: String): GeoLocation {
        val location = GeoHash.locationFromHash(geoHash)
        return GeoLocation(location.latitude, location.longitude)
    }

    private fun showLocationRequestAlert(customerName: String, customerLocation: LatLng) {
        val currentUserId = FirebaseAuth.getInstance().currentUser?.uid
        if (currentUserId != null) {
            val driverLocationRef =
                FirebaseDatabase.getInstance().getReference("DriverLocationReference")
                    .child(currentUserId)
            driverLocationRef.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {

                    val currentUserId = FirebaseAuth.getInstance().currentUser?.uid
                    if (currentUserId != null) {

                        val locationArray = dataSnapshot.child(currentUserId).child("l").getValue(Array<Double>::class.java)
                        val driverLatitude = locationArray?.get(0) ?: 0.0
                        val driverLongitude = locationArray?.get(1) ?: 0.0


                    Log.d(
                        "DatabaseRetrieval",
                        "Driver Location - Latitude: $driverLatitude, Longitude: $driverLongitude"
                    )
                    if (driverLatitude != null && driverLongitude != null) {
                        val currentLocation = LatLng(driverLatitude, driverLongitude)
                        val distance = calculateDistance(currentLocation, customerLocation)

                        val formattedDistance = if (distance < 0.6) {
                            String.format(Locale.getDefault(), "%.0f meters", distance * 1000)
                        } else {
                            String.format(Locale.getDefault(), "%.2f km", distance)
                        }



                        val inflater = LayoutInflater.from(this@DriverMapsActivity)
                        val customSnackbarView = inflater.inflate(R.layout.custom_snackbar, null)


                        val snackbar = Snackbar.make(customSnackbarView, "Customer $customerName is $formattedDistance away. Accept or decline request?", Snackbar.LENGTH_INDEFINITE)

                        val acceptButton = customSnackbarView.findViewById<Button>(R.id.accept_button)
                        val declineButton = customSnackbarView.findViewById<Button>(R.id.decline_button)

                        acceptButton.setOnClickListener {
                            val carpoolRequestsRef = FirebaseDatabase.getInstance().getReference("CarpoolRequests")


                            carpoolRequestsRef.addListenerForSingleValueEvent(object : ValueEventListener {
                                override fun onDataChange(dataSnapshot: DataSnapshot) {
                                    // Iterate through each child node
                                    for (childSnapshot in dataSnapshot.children) {
                                        // Get the UID and customer destination from the child node
                                        val uid = childSnapshot.child("uid").getValue(String::class.java)
                                        val destination = childSnapshot.child("destination")
                                        val latitude = destination.child("latitude").getValue(Double::class.java)
                                        val longitude = destination.child("longitude").getValue(Double::class.java)

                                        // Check if the UID and destination values are not null
                                        if (uid != null && latitude != null && longitude != null) {
                                            // Construct the customer location string
                                            val customerLocation = "$latitude,$longitude"

                                            // Construct the accepted request data
                                            val acceptedRequestData = HashMap<String, Any>()
                                            acceptedRequestData["CustomerLocation"] = customerLocation
                                            acceptedRequestData["CustomerDestination"] = "$latitude,$longitude" // You may format this as needed
                                            acceptedRequestData["DriverID"] = FirebaseAuth.getInstance().currentUser!!.uid

                                            // Push the data to the "acceptedRequests" node
                                            carpoolRequestsRef.push().setValue(acceptedRequestData)

                                            // Exit the loop if the desired UID is found
                                            break
                                        }
                                    }
                                }

                                override fun onCancelled(databaseError: DatabaseError) {
                                    // Handle errors
                                }
                            })

                    }
                        declineButton.setOnClickListener {
                            snackbar.dismiss()
                            Log.d("Snackbar", "Decline button clicked")
                        }

                        snackbar.show()
                    } else {
                        Log.e("DatabaseRetrieval", "Failed to get current location for driver 1111")
                        Snackbar.make(
                            findViewById(android.R.id.content),
                            "Failed to get current location1111",
                            Snackbar.LENGTH_LONG
                        ).show()
                    }
                }}

                override fun onCancelled(databaseError: DatabaseError) {
                    Log.e("DatabaseRetrieval", "Database Error: ${databaseError.message}")
                    // Handle error (if needed)
                    Snackbar.make(
                        findViewById(android.R.id.content),
                        "Failed to get current location2222",
                        Snackbar.LENGTH_LONG
                    ).show()
                }
            })
        } else {
            Snackbar.make(
                findViewById(android.R.id.content),
                "User not authenticated",
                Snackbar.LENGTH_LONG
            ).show()
        }
    }



    private fun calculateDistance(location1: LatLng, location2: LatLng): Double {
        return SphericalUtil.computeDistanceBetween(location1, location2)
    }

    // Call this method when a live location request is made
    private fun onLiveLocationRequestReceived(customerName: String, customerLocation: LatLng) {
        showLocationRequestAlert(customerName, customerLocation)
    }
    private fun resizeBitmap(imageResId: Int, width: Int, height: Int): Bitmap {
        val originalBitmap = BitmapFactory.decodeResource(resources, imageResId)
        return Bitmap.createScaledBitmap(originalBitmap, width, height, false)
    }



}