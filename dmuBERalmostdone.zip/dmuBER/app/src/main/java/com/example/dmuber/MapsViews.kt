package com.example.dmuber
import android.Manifest
import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.dmuber.R
import com.google.android.gms.location.*
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.firebase.geofire.GeoFire
import com.firebase.geofire.GeoFireUtils
import com.firebase.geofire.GeoLocation
import com.firebase.geofire.GeoQueryEventListener
import com.firebase.geofire.core.GeoHash
import com.firebase.geofire.util.GeoUtils
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MapsViews : AppCompatActivity(), OnMapReadyCallback, GoogleMap.OnMapLongClickListener, GoogleMap.OnMarkerClickListener  {

    private lateinit var mMap: GoogleMap
    private lateinit var mapView: MapView

    private var carpoolRequestKey: String? = null

    private lateinit var locationRequest: LocationRequest
    private lateinit var locationCallback: LocationCallback
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient

    private lateinit var onlineRef: DatabaseReference
    private lateinit var currentUserRef: DatabaseReference
    private lateinit var CustomerLocationReference: DatabaseReference
    private lateinit var geoFire: GeoFire

    private lateinit var progressDialog: ProgressDialog

    private val onlineValueEventListener = object : ValueEventListener {
        override fun onCancelled(error: DatabaseError) {
            Snackbar.make(findViewById(android.R.id.content), error.message, Snackbar.LENGTH_LONG)
                .show()
        }

        override fun onDataChange(snapshot: DataSnapshot) {
            if (snapshot.exists()) {
                currentUserRef.onDisconnect().removeValue()
            }
        }
    }

    private var userMarker: Marker? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)

        progressDialog = ProgressDialog(this)

        mapView = findViewById(R.id.map_view)
        mapView.onCreate(savedInstanceState)
        mapView.onResume()
        mapView.getMapAsync(this)

        init()
    }

    private fun init() {
        onlineRef = FirebaseDatabase.getInstance().getReference(".info/connected")
        CustomerLocationReference =
            FirebaseDatabase.getInstance().getReference("CustomerLocationReference")
        currentUserRef = FirebaseDatabase.getInstance().getReference("CustomerLocationReference")
            .child(FirebaseAuth.getInstance().currentUser!!.uid)

        geoFire = GeoFire(CustomerLocationReference)

        registerOnlineSystem()

        locationRequest = LocationRequest()
        locationRequest.apply {
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
            fastestInterval = 3000
            interval = 5000
            smallestDisplacement = 10f
        }

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                super.onLocationResult(locationResult)
                val location = locationResult.lastLocation
                location?.let { updateLocation(it) }
            }
        }

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)
        startLocationUpdates()
    }

    private fun startLocationUpdates() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationProviderClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
            )
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                12
            )
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.mapType = GoogleMap.MAP_TYPE_NORMAL

        mMap.setOnMapLongClickListener(this)
        mMap.setOnMarkerClickListener(this)

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            mMap.isMyLocationEnabled = true
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun updateLocation(location: Location) {
        val newPos = LatLng(location.latitude, location.longitude)
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(newPos, 18f))
        geoFire.setLocation(
            FirebaseAuth.getInstance().currentUser!!.uid,
            GeoLocation(location.latitude, location.longitude)
        ) { key: String?, error: DatabaseError? ->
            if (error != null) {
                Snackbar.make(
                    findViewById(android.R.id.content),
                    error.message,
                    Snackbar.LENGTH_LONG
                ).show()
            } else {
                Snackbar.make(
                    findViewById(android.R.id.content),
                    "You're online!",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun registerOnlineSystem() {
        onlineRef.addValueEventListener(onlineValueEventListener)
    }

    override fun onDestroy() {
        super.onDestroy()
        fusedLocationProviderClient.removeLocationUpdates(locationCallback)
        geoFire.removeLocation(FirebaseAuth.getInstance().currentUser!!.uid)
        onlineRef.removeEventListener(onlineValueEventListener)
        carpoolRequestKey?.let { key ->
            val requestsRef = FirebaseDatabase.getInstance().getReference("CarpoolRequests").child(key)
            requestsRef.removeValue()
        }
    }

    override fun onMapLongClick(latLng: LatLng) {
        addMarkerToMap(latLng)
    }


    override fun onMarkerClick(marker: Marker): Boolean {
        if (marker == userMarker) {
            showLiveCarpoolRequestButton(marker)
        }
        return false
    }


    private fun showLiveCarpoolRequestButton(marker: Marker) {
        val button = Button(this)
        button.text = "Live Carpool Request"
        button.setOnClickListener {
            sendCarpoolRequest(marker.position)
            progressDialog.show()
        }
        // You can customize the button appearance here if needed
       AlertDialog.Builder(this)
            .setView(button)
            .show()

        progressDialog.setOnDismissListener {
            carpoolRequestKey?.let { key ->
                val requestsRef = FirebaseDatabase.getInstance().getReference("CarpoolRequests").child(key)
                requestsRef.removeValue()
            }
        }
    }

    private fun sendCarpoolRequest(destination: LatLng) {
        val currentUser = FirebaseAuth.getInstance().currentUser
        val currentTime = getCurrentTime()
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationProviderClient.lastLocation.addOnSuccessListener { location: Location? ->
                location?.let {
                    // Location retrieved successfully, now send the carpool request
                    val requestRef =
                        FirebaseDatabase.getInstance().getReference("CarpoolRequests").push()
                    val request = mapOf(
                        "uid" to currentUser?.uid,
                        "destination" to destination,
                        "time" to currentTime,
                        "currentLocation" to LatLng(location.latitude, location.longitude)
                    )
                    requestRef.setValue(request)
                    Log.d("CarpoolRequest", "Carpool request key: $carpoolRequestKey")
                    carpoolRequestKey = requestRef.key
                }
            }.addOnFailureListener { exception ->
                // Handle failure to retrieve the location
                Snackbar.make(
                    findViewById(android.R.id.content),
                    "Failed to get current location: ${exception.message}",
                    Snackbar.LENGTH_LONG
                ).show()
            }
        } else {
            // Location permission not granted, request it
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun getCurrentTime(): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val currentTime = Calendar.getInstance().time
        return dateFormat.format(currentTime)
    }

    private fun addMarkerToMap(latLng: LatLng) {
        if (::userMarker != null) {
            userMarker?.remove()
        }
        userMarker = mMap.addMarker(MarkerOptions().position(latLng).title("Destination"))
        saveDestinationToFirebase(latLng)
    }

    private fun saveDestinationToFirebase(latLng: LatLng) {
        val currentUser = FirebaseAuth.getInstance().currentUser
        currentUser?.let {
            val destinationRef =
                FirebaseDatabase.getInstance().getReference("UserDestinations").child(it.uid)
            destinationRef.setValue(latLng)
        }
    }
    override fun onBackPressed() {
        // Dismiss the progress dialog if it's showing
        progressDialog.dismiss()

        Log.d("CarpoolRequest deleted", "Carpool request key: $carpoolRequestKey")
        carpoolRequestKey?.let { key ->
            val requestsRef = FirebaseDatabase.getInstance().getReference("CarpoolRequests").child(key)
            requestsRef.removeValue()
        }

        super.onBackPressed()
    }

    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 100
    }

//
//    private fun initiateGeoQuery(geoFireHash: String) {
//        val geoQuery = geoFire.queryAtLocation(geoLocationFromGeoHash(geoFireHash), 1.0) // 1.0 is the radius in kilometers, adjust as needed
//        geoQuery.addGeoQueryEventListener(object : GeoQueryEventListener {
//            override fun onKeyEntered(key: String?, location: GeoLocation?) {
//                location?.let {
//                    val customerLocation = LatLng(it.latitude, it.longitude)
//                    updateBlipPosition(customerLocation)
//                }
//            }
//
//            override fun onKeyExited(key: String?) {
//                // Handle case when the key exits
//            }
//
//            override fun onKeyMoved(key: String?, location: GeoLocation?) {
//                location?.let {
//                    val customerLocation = LatLng(it.latitude, it.longitude)
//                    updateBlipPosition(customerLocation)
//                }
//            }
//
//            override fun onGeoQueryReady() {
//                // All initial data has been loaded and events have been fired
//            }
//
//            override fun onGeoQueryError(error: DatabaseError?) {
//                // Handle error
//            }
//        })
//    }
//
//    // Function to update blip's position on the map
//    private fun updateBlipPosition(location: LatLng) {
//        // Update the position of the blip on the map
//        // For example:
//        mMap.clear() // Clear previous markers
//        mMap.addMarker(MarkerOptions().position(location).title("Customer Blip"))
//        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 15f))
//
//    }

//    private fun geoLocationFromGeoHash(geoHash: String): GeoLocation {
//        val location = GeoHash.locationFromHash(geoHash)
//        return GeoLocation(location.latitude, location.longitude)
//    }


}